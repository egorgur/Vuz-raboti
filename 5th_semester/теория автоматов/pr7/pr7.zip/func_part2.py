def some_function(a, b):
    c = a + b
    d = a * c
    e = b - a
    f = c * d
    g = a + d
    h = e * f
    i = g - b
    j = h + i
    k = d * e
    result = j + k
    return result
