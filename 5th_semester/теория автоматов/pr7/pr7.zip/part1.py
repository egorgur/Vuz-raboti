class BaseFunctionsForPrimitiveRecursion:
    def zero(self):
        """Z() = 0"""
        return 0

    def succ(self, n):
        """S(n) = n + 1"""
        return n + 1

    def pred(self, n):
        """Предшественник: pred(n) = n - 1 для n > 0, иначе 0"""
        return max(0, n - 1)


class Calculator(BaseFunctionsForPrimitiveRecursion):
    def add(self, x, y):
        """
        Сложение:
        add(x, 0) = x
        add(x, y+1) = succ(add(x, y))
        """
        if y == 0:
            return x
        else:
            return self.succ(self.add(x, self.pred(y)))

    def mult(self, x, y):
        """
        Умножение:
        mult(x, 0) = 0
        mult(x, y+1) = add(mult(x, y), x)
        """
        if y == 0:
            return self.zero()
        else:
            return self.add(self.mult(x, self.pred(y)), x)

    def power(self, x, y):
        """
        Возведение в степень:
        power(x, 0) = 1
        power(x, y+1) = mult(power(x, y), x)
        """
        if y == 0:
            return self.succ(self.zero())  # = 1
        else:
            return self.mult(self.power(x, self.pred(y)), x)

    def power_signed(self, x, y):
        """Возведение в степень с учётом знака основания"""
        if y < 0:
            raise ValueError("Отрицательный показатель не поддерживается")
        if y == 0:
            return 1

        abs_x = abs(x)
        result = self.power(abs_x, y)

        if x < 0 and y % 2 == 1:
            return -result
        return result


if __name__ == "__main__":
    examples = [
        (4, 3),
        (2, 10),
        (3, 4),
    ]

    calc = Calculator()

    for x, y in examples:
        result = calc.power_signed(x, y)
        print(f"{x:>6} ^ {y:<5} = {result:>12}")
