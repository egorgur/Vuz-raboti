from typing import Any, Literal


class BasePrimitiveFunctions:
    @staticmethod
    def zero(*args) -> Literal[0]:
        """
        Нулевая функция: Z() = 0 или O^n(x_1,...,x_n) = 0
        Возвращает 0 для любых аргументов
        """
        return 0

    @staticmethod
    def succ(n) -> Any:
        """
        Функция следования: S(n) = n + 1
        """
        return n + 1

    @staticmethod
    def proj(k, *args) -> Any:
        """
        Функция проекции: I^n_k(x_1, ..., x_n) = x_k
        Возвращает k-й аргумент

        Пример: proj(1, a, b, c) = b
        """
        return args[k]


class PrimitiveRecursion(BasePrimitiveFunctions):
    def pred(self, n) -> Any | Literal[0]:
        """
        Предшественник через ПРИМИТИВНУЮ РЕКУРСИЮ:
        pred(0) = 0 = Z()
        pred(S(n)) = n = I^2_0(n, pred(n))
        """
        if n == 0:
            return self.zero()
        else:
            prev_result = self.pred(n - 1)
            return self.proj(0, n - 1, prev_result)

    def add(self, x, y) -> Any:  # # -> Any:
        """
        Сложение через ПРИМИТИВНУЮ РЕКУРСИЮ:
        add(x, 0) = x = I^1_0(x)              -- базовый случай
        add(x, S(y)) = S(add(x, y))           -- рекурсивный шаг
        """
        if y == 0:
            return self.proj(0, x)
        else:
            return self.succ(self.add(x, y - 1))

    def mult(self, x, y) -> Any | Literal[0]:
        """
        Умножение через ПРИМИТИВНУЮ РЕКУРСИЮ:
        mult(x, 0) = 0 = Z()                  -- базовый случай
        mult(x, S(y)) = add(mult(x, y), x)    -- рекурсивный шаг
        """
        if y == 0:
            return self.zero()
        else:
            return self.add(self.mult(x, y - 1), x)

    def power(self, x, y) -> Any | Literal[0]:
        """
        Возведение в степень через ПРИМИТИВНУЮ РЕКУРСИЮ:
        power(x, 0) = 1 = S(Z())              -- базовый случай
        power(x, S(y)) = mult(power(x, y), x) -- рекурсивный шаг
        """
        if y == 0:
            return self.succ(self.zero())
        else:
            return self.mult(self.power(x, y - 1), x)


class Calculator(PrimitiveRecursion):
    def square(self, x) -> Any | Literal[0]:
        """
        g(x) = x² через СУПЕРПОЗИЦИЮ
        """
        return self.mult(self.proj(0, x), self.proj(0, x))

    def power_self(self, x) -> Any | Literal[0]:
        """
        f(x) = x^x через СУПЕРПОЗИЦИЮ
        """
        return self.power(self.proj(0, x), self.proj(0, x))

    def cube(self, x) -> Any | Literal[0]:
        """
        c(x) = x³ через СУПЕРПОЗИЦИЮ
        """
        return self.mult(self.square(x), self.proj(0, x))


if __name__ == "__main__":
    calc = Calculator()
    print("Вычислитель x^y")
    examples = [(1, 3), (4, 2), (2, 4)]
    for x, y in examples:
        result = calc.power(x, y)
        print(f"  {x:>4} ^ {y:<4} = {result:>10}")

    print("Вычислитель x^x")
    for x in (1, 2, 3, 5):
        result = calc.power_self(x)
        print(f"  {x:>4} ^ {x:<4} = {result:>10}")
