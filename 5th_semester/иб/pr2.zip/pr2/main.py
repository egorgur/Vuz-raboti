from gui import RSAApp

if __name__ == "__main__":
    app = RSAApp()
    app.run()

