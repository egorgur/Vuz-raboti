"""
Модуль работы с базой данных (SQLite).
"""

import sqlite3
import threading
from typing import Optional, List, Dict, Any
from contextlib import contextmanager
from dataclasses import dataclass
from security import password_manager, Role


@dataclass
class User:
    id: int
    username: str
    password_hash: str
    role: str
    is_active: bool


@dataclass
class Note:
    id: int
    user_id: int
    title: str
    content: str
    created_at: float
    updated_at: float


class Database:
    """Потокобезопасная работа с SQLite"""

    _local = threading.local()

    def __init__(self, db_path: str = "secure_notes.db"):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Получение соединения для текущего потока"""
        if not hasattr(self._local, 'connection'):
            self._local.connection = sqlite3.connect(
                self.db_path,
                check_same_thread=False
            )
            self._local.connection.row_factory = sqlite3.Row
        return self._local.connection

    @contextmanager
    def get_cursor(self):
        """Контекстный менеджер для курсора"""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            yield cursor
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e

    def _init_db(self):
        """Инициализация таблиц"""
        with self.get_cursor() as cursor:
            # Таблица пользователей
            cursor.execute('''
                           CREATE TABLE IF NOT EXISTS users (
                                                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                                username TEXT UNIQUE NOT NULL,
                                                                password_hash TEXT NOT NULL,
                                                                role TEXT NOT NULL DEFAULT 'user',
                                                                is_active INTEGER NOT NULL DEFAULT 1,
                                                                created_at REAL NOT NULL
                           )
                           ''')

            # Таблица заметок
            cursor.execute('''
                           CREATE TABLE IF NOT EXISTS notes (
                                                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                                user_id INTEGER NOT NULL,
                                                                title TEXT NOT NULL,
                                                                content TEXT NOT NULL,
                                                                created_at REAL NOT NULL,
                                                                updated_at REAL NOT NULL,
                                                                FOREIGN KEY (user_id) REFERENCES users (id)
                               )
                           ''')

            # Создаём администратора по умолчанию
            cursor.execute('SELECT COUNT(*) FROM users WHERE role = ?', (Role.ADMIN.value,))
            if cursor.fetchone()[0] == 0:
                import time
                admin_hash = password_manager.hash_password("admin123")
                cursor.execute('''
                               INSERT INTO users (username, password_hash, role, created_at)
                               VALUES (?, ?, ?, ?)
                               ''', ('admin', admin_hash, Role.ADMIN.value, time.time()))

    # ============== ПОЛЬЗОВАТЕЛИ ==============

    def create_user(self, username: str, password: str, role: str = "user") -> Optional[int]:
        """Создание пользователя"""
        import time
        password_hash = password_manager.hash_password(password)

        try:
            with self.get_cursor() as cursor:
                cursor.execute('''
                               INSERT INTO users (username, password_hash, role, created_at)
                               VALUES (?, ?, ?, ?)
                               ''', (username, password_hash, role, time.time()))
                return cursor.lastrowid
        except sqlite3.IntegrityError:
            return None

    def get_user_by_username(self, username: str) -> Optional[User]:
        """Получение пользователя по имени"""
        with self.get_cursor() as cursor:
            cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
            row = cursor.fetchone()
            if row:
                return User(
                    id=row['id'],
                    username=row['username'],
                    password_hash=row['password_hash'],
                    role=row['role'],
                    is_active=bool(row['is_active'])
                )
        return None

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """Получение пользователя по ID"""
        with self.get_cursor() as cursor:
            cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            row = cursor.fetchone()
            if row:
                return User(
                    id=row['id'],
                    username=row['username'],
                    password_hash=row['password_hash'],
                    role=row['role'],
                    is_active=bool(row['is_active'])
                )
        return None

    def get_all_users(self) -> List[User]:
        """Получение всех пользователей"""
        with self.get_cursor() as cursor:
            cursor.execute('SELECT * FROM users ORDER BY id')
            return [
                User(
                    id=row['id'],
                    username=row['username'],
                    password_hash=row['password_hash'],
                    role=row['role'],
                    is_active=bool(row['is_active'])
                )
                for row in cursor.fetchall()
            ]

    def update_user_role(self, user_id: int, role: str) -> bool:
        """Обновление роли пользователя"""
        with self.get_cursor() as cursor:
            cursor.execute(
                'UPDATE users SET role = ? WHERE id = ?',
                (role, user_id)
            )
            return cursor.rowcount > 0

    def toggle_user_active(self, user_id: int) -> bool:
        """Переключение статуса активности"""
        with self.get_cursor() as cursor:
            cursor.execute(
                'UPDATE users SET is_active = NOT is_active WHERE id = ?',
                (user_id,)
            )
            return cursor.rowcount > 0

    # ============== ЗАМЕТКИ ==============

    def create_note(self, user_id: int, title: str, content: str) -> int:
        """Создание заметки"""
        import time
        now = time.time()
        with self.get_cursor() as cursor:
            cursor.execute('''
                           INSERT INTO notes (user_id, title, content, created_at, updated_at)
                           VALUES (?, ?, ?, ?, ?)
                           ''', (user_id, title, content, now, now))
            return cursor.lastrowid

    def get_note_by_id(self, note_id: int) -> Optional[Note]:
        """Получение заметки по ID"""
        with self.get_cursor() as cursor:
            cursor.execute('SELECT * FROM notes WHERE id = ?', (note_id,))
            row = cursor.fetchone()
            if row:
                return Note(
                    id=row['id'],
                    user_id=row['user_id'],
                    title=row['title'],
                    content=row['content'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
        return None

    def get_user_notes(self, user_id: int) -> List[Note]:
        """Получение заметок пользователя"""
        with self.get_cursor() as cursor:
            cursor.execute(
                'SELECT * FROM notes WHERE user_id = ? ORDER BY updated_at DESC',
                (user_id,)
            )
            return [
                Note(
                    id=row['id'],
                    user_id=row['user_id'],
                    title=row['title'],
                    content=row['content'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
                for row in cursor.fetchall()
            ]

    def get_all_notes(self) -> List[Note]:
        """Получение всех заметок"""
        with self.get_cursor() as cursor:
            cursor.execute('SELECT * FROM notes ORDER BY updated_at DESC')
            return [
                Note(
                    id=row['id'],
                    user_id=row['user_id'],
                    title=row['title'],
                    content=row['content'],
                    created_at=row['created_at'],
                    updated_at=row['updated_at']
                )
                for row in cursor.fetchall()
            ]

    def update_note(self, note_id: int, title: str, content: str) -> bool:
        """Обновление заметки"""
        import time
        with self.get_cursor() as cursor:
            cursor.execute('''
                           UPDATE notes SET title = ?, content = ?, updated_at = ?
                           WHERE id = ?
                           ''', (title, content, time.time(), note_id))
            return cursor.rowcount > 0

    def delete_note(self, note_id: int) -> bool:
        """Удаление заметки"""
        with self.get_cursor() as cursor:
            cursor.execute('DELETE FROM notes WHERE id = ?', (note_id,))
            return cursor.rowcount > 0


# Глобальный экземпляр
db = Database()