"""
Основное приложение FastAPI с нативной аутентификацией и авторизацией.
"""

from fastapi import FastAPI, Request, Response, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import time
from typing import Optional
from functools import wraps

from security import (
    token_manager, csrf_protection, brute_force_protection,
    xss_protection, audit_log, password_manager,
    Role, Permission, has_permission, SessionToken
)
from database import db, User, Note


# ============== ПРИЛОЖЕНИЕ ==============
app = FastAPI(title="Secure Notes", docs_url=None, redoc_url=None)

# Статические файлы и шаблоны
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


# ============== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==============

def get_client_ip(request: Request) -> str:
    """Получение IP клиента"""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def get_user_agent(request: Request) -> str:
    """Получение User-Agent"""
    return request.headers.get("User-Agent", "unknown")


def get_current_user(request: Request) -> Optional[SessionToken]:
    """
    Извлечение и валидация токена из cookies.
    Проверяет привязку к IP и User-Agent.
    """
    token = request.cookies.get("session_token")
    if not token:
        return None

    ip = get_client_ip(request)
    ua = get_user_agent(request)

    user = token_manager.validate_token(token, ip, ua)

    # ИСПРАВЛЕНИЕ: Сохраняем валидированного пользователя в состояние запроса
    if user:
        request.state.user = user

    return user


def set_auth_cookie(response: Response, token: str):
    """Установка cookie с токеном"""
    response.set_cookie(
        key="session_token",
        value=token,
        httponly=True,  # Защита от XSS (JavaScript не может прочитать)
        samesite="strict",  # Защита от CSRF
        max_age=300  # 5 минут (короткий TTL)
    )


def clear_auth_cookie(response: Response):
    """Удаление cookie"""
    response.delete_cookie("session_token")


def check_permission(user_token: SessionToken, permission: Permission) -> bool:
    """Проверка разрешения для пользователя"""
    try:
        role = Role(user_token.role)
        return has_permission(role, permission)
    except ValueError:
        return False


# ============== MIDDLEWARE ==============

@app.middleware("http")
async def security_middleware(request: Request, call_next):
    """Middleware для безопасности"""
    response = await call_next(request)

    # Заголовки безопасности
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'"

    should_refresh = (
            (response.status_code == 200 or response.status_code in [302, 303]) and
            not request.url.path.startswith("/static") and
            request.url.path not in ["/logout", "/login", "/register"]
    )

    if should_refresh:
        # Проверяем, был ли валидирован пользователь (код из предыдущего исправления)
        if hasattr(request.state, "user") and request.state.user:
            ip = get_client_ip(request)
            ua = get_user_agent(request)

            # Генерируем новый токен, сохраняя session_id (код из предыдущего исправления)
            new_token = token_manager.create_token(
                user_id=request.state.user.user_id,
                role=request.state.user.role,
                ip=ip,
                user_agent=ua,
                session_id=request.state.user.session_id
            )
            set_auth_cookie(response, new_token)

    return response


# ============== ПУБЛИЧНЫЕ МАРШРУТЫ ==============

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Главная страница"""
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)
    return RedirectResponse(url="/login", status_code=303)


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Страница входа"""
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)

    ip = get_client_ip(request)
    locked = brute_force_protection.is_locked(ip)
    remaining = brute_force_protection.get_remaining_attempts(ip)

    return templates.TemplateResponse("login.html", {
        "request": request,
        "error": None,
        "locked": locked,
        "remaining_attempts": remaining
    })


@app.post("/login")
async def login(
        request: Request,
        response: Response,
        username: str = Form(...),
        password: str = Form(...)
):
    """Обработка входа"""
    ip = get_client_ip(request)
    ua = get_user_agent(request)

    # Проверка блокировки
    if brute_force_protection.is_locked(ip):
        audit_log.log(None, "LOGIN_BLOCKED", ip, f"IP заблокирован: {username}")
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "IP-адрес заблокирован. Попробуйте позже.",
            "locked": True,
            "remaining_attempts": 0
        })

    # Санитизация входных данных
    username = xss_protection.sanitize(username.strip())

    # Проверка пользователя
    user = db.get_user_by_username(username)

    if not user or not password_manager.verify_password(password, user.password_hash):
        brute_force_protection.record_attempt(ip, success=False)
        remaining = brute_force_protection.get_remaining_attempts(ip)

        audit_log.log(None, "LOGIN_FAILED", ip, f"Неверные данные: {username}", success=False)

        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": f"Неверное имя пользователя или пароль. Осталось попыток: {remaining}",
            "locked": False,
            "remaining_attempts": remaining
        })

    # Проверка активности
    if not user.is_active:
        audit_log.log(user.id, "LOGIN_DISABLED", ip, "Аккаунт деактивирован", success=False)
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Аккаунт деактивирован. Обратитесь к администратору.",
            "locked": False,
            "remaining_attempts": brute_force_protection.get_remaining_attempts(ip)
        })

    # Успешный вход
    brute_force_protection.record_attempt(ip, success=True)
    token = token_manager.create_token(user.id, user.role, ip, ua)

    audit_log.log(user.id, "LOGIN_SUCCESS", ip, f"Пользователь: {username}")

    response = RedirectResponse(url="/dashboard", status_code=303)
    set_auth_cookie(response, token)
    return response


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    """Страница регистрации"""
    user = get_current_user(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=303)

    return templates.TemplateResponse("register.html", {
        "request": request,
        "error": None
    })


@app.post("/register")
async def register(
        request: Request,
        username: str = Form(...),
        password: str = Form(...),
        password_confirm: str = Form(...)
):
    """Обработка регистрации"""
    ip = get_client_ip(request)

    # Санитизация
    username = xss_protection.sanitize(username.strip())

    # Валидация
    errors = []

    if len(username) < 3 or len(username) > 50:
        errors.append("Имя пользователя должно быть от 3 до 50 символов")

    if not username.replace("_", "").isalnum():
        errors.append("Имя может содержать только буквы, цифры и _")

    if len(password) < 8:
        errors.append("Пароль должен быть не менее 8 символов")

    if password != password_confirm:
        errors.append("Пароли не совпадают")

    if errors:
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": " ".join(errors)
        })

    # Создание пользователя
    user_id = db.create_user(username, password, Role.USER.value)

    if not user_id:
        audit_log.log(None, "REGISTER_FAILED", ip, f"Имя занято: {username}", success=False)
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "Пользователь с таким именем уже существует"
        })

    audit_log.log(user_id, "REGISTER_SUCCESS", ip, f"Новый пользователь: {username}")

    return RedirectResponse(url="/login", status_code=303)


@app.get("/logout")
async def logout(request: Request):
    """Выход из системы"""
    user = get_current_user(request)
    ip = get_client_ip(request)

    if user:
        token_manager.invalidate_user_sessions(user.user_id)
        audit_log.log(user.user_id, "LOGOUT", ip)

    response = RedirectResponse(url="/login", status_code=303)
    clear_auth_cookie(response)
    return response


# ============== ЗАЩИЩЁННЫЕ МАРШРУТЫ ==============

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Панель управления"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    db_user = db.get_user_by_id(user.user_id)
    if not db_user:
        return RedirectResponse(url="/logout", status_code=303)

    # Получаем заметки в зависимости от прав
    role = Role(user.role)

    if has_permission(role, Permission.READ_ALL_NOTES):
        notes = db.get_all_notes()
    else:
        notes = db.get_user_notes(user.user_id)

    # Генерация CSRF-токена
    csrf_token = csrf_protection.generate_token(user.session_id)

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": db_user,
        "notes": notes,
        "csrf_token": csrf_token,
        "can_view_all": has_permission(role, Permission.READ_ALL_NOTES),
        "can_manage_users": has_permission(role, Permission.MANAGE_USERS),
        "can_view_audit": has_permission(role, Permission.VIEW_AUDIT_LOG)
    })


@app.post("/notes/create")
async def create_note(
        request: Request,
        title: str = Form(...),
        content: str = Form(...),
        csrf_token: str = Form(...)
):
    """Создание заметки"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Не авторизован")

    # Проверка CSRF
    if not csrf_protection.validate_token(csrf_token, user.session_id):
        audit_log.log(user.user_id, "CSRF_ATTACK", get_client_ip(request), success=False)
        raise HTTPException(status_code=403, detail="Недействительный CSRF-токен")

    # Проверка прав
    if not check_permission(user, Permission.CREATE_NOTE):
        raise HTTPException(status_code=403, detail="Недостаточно прав")

    # Санитизация
    title = xss_protection.sanitize(title.strip())
    content = xss_protection.sanitize(content.strip())

    # Валидация
    if not title or len(title) > 200:
        raise HTTPException(status_code=400, detail="Некорректный заголовок")

    if not content or len(content) > 10000:
        raise HTTPException(status_code=400, detail="Некорректное содержимое")

    note_id = db.create_note(user.user_id, title, content)
    audit_log.log(user.user_id, "CREATE_NOTE", get_client_ip(request), f"Note ID: {note_id}")

    return RedirectResponse(url="/dashboard", status_code=303)


@app.post("/notes/{note_id}/edit")
async def edit_note(
        request: Request,
        note_id: int,
        title: str = Form(...),
        content: str = Form(...),
        csrf_token: str = Form(...)
):
    """Редактирование заметки"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Не авторизован")

    # Проверка CSRF
    if not csrf_protection.validate_token(csrf_token, user.session_id):
        raise HTTPException(status_code=403, detail="Недействительный CSRF-токен")

    # Получение заметки
    note = db.get_note_by_id(note_id)
    if not note:
        raise HTTPException(status_code=404, detail="Заметка не найдена")

    # Проверка прав
    role = Role(user.role)
    is_owner = note.user_id == user.user_id

    if is_owner:
        if not has_permission(role, Permission.EDIT_OWN_NOTES):
            raise HTTPException(status_code=403, detail="Недостаточно прав")
    else:
        if not has_permission(role, Permission.EDIT_ALL_NOTES):
            raise HTTPException(status_code=403, detail="Недостаточно прав")

    # Санитизация и обновление
    title = xss_protection.sanitize(title.strip())
    content = xss_protection.sanitize(content.strip())

    db.update_note(note_id, title, content)
    audit_log.log(user.user_id, "EDIT_NOTE", get_client_ip(request), f"Note ID: {note_id}")

    return RedirectResponse(url="/dashboard", status_code=303)


@app.post("/notes/{note_id}/delete")
async def delete_note(
        request: Request,
        note_id: int,
        csrf_token: str = Form(...)
):
    """Удаление заметки"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Не авторизован")

    # Проверка CSRF
    if not csrf_protection.validate_token(csrf_token, user.session_id):
        raise HTTPException(status_code=403, detail="Недействительный CSRF-токен")

    # Получение заметки
    note = db.get_note_by_id(note_id)
    if not note:
        raise HTTPException(status_code=404, detail="Заметка не найдена")

    # Проверка прав
    role = Role(user.role)
    is_owner = note.user_id == user.user_id

    if is_owner:
        if not has_permission(role, Permission.DELETE_OWN_NOTES):
            raise HTTPException(status_code=403, detail="Недостаточно прав")
    else:
        if not has_permission(role, Permission.DELETE_ALL_NOTES):
            raise HTTPException(status_code=403, detail="Недостаточно прав")

    db.delete_note(note_id)
    audit_log.log(user.user_id, "DELETE_NOTE", get_client_ip(request), f"Note ID: {note_id}")

    return RedirectResponse(url="/dashboard", status_code=303)


# ============== АДМИНИСТРАТИВНЫЕ МАРШРУТЫ ==============

@app.get("/admin", response_class=HTMLResponse)
async def admin_panel(request: Request):
    """Панель администратора"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not check_permission(user, Permission.MANAGE_USERS):
        raise HTTPException(status_code=403, detail="Недостаточно прав")

    db_user = db.get_user_by_id(user.user_id)
    users = db.get_all_users()
    csrf_token = csrf_protection.generate_token(user.session_id)

    return templates.TemplateResponse("admin.html", {
        "request": request,
        "user": db_user,
        "users": users,
        "roles": [r.value for r in Role],
        "csrf_token": csrf_token
    })


@app.post("/admin/users/{user_id}/role")
async def change_user_role(
        request: Request,
        user_id: int,
        role: str = Form(...),
        csrf_token: str = Form(...)
):
    """Изменение роли пользователя"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Не авторизован")

    if not csrf_protection.validate_token(csrf_token, user.session_id):
        raise HTTPException(status_code=403, detail="Недействительный CSRF-токен")

    if not check_permission(user, Permission.MANAGE_USERS):
        raise HTTPException(status_code=403, detail="Недостаточно прав")

    # Нельзя менять свою роль
    if user_id == user.user_id:
        raise HTTPException(status_code=400, detail="Нельзя изменить свою роль")

    # Проверка валидности роли
    try:
        Role(role)
    except ValueError:
        raise HTTPException(status_code=400, detail="Недопустимая роль")

    db.update_user_role(user_id, role)
    token_manager.invalidate_user_sessions(user_id)  # Сброс сессий

    audit_log.log(user.user_id, "CHANGE_ROLE", get_client_ip(request),
                  f"User {user_id} -> {role}")

    return RedirectResponse(url="/admin", status_code=303)


@app.post("/admin/users/{user_id}/toggle")
async def toggle_user(
        request: Request,
        user_id: int,
        csrf_token: str = Form(...)
):
    """Активация/деактивация пользователя"""
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Не авторизован")

    if not csrf_protection.validate_token(csrf_token, user.session_id):
        raise HTTPException(status_code=403, detail="Недействительный CSRF-токен")

    if not check_permission(user, Permission.MANAGE_USERS):
        raise HTTPException(status_code=403, detail="Недостаточно прав")

    if user_id == user.user_id:
        raise HTTPException(status_code=400, detail="Нельзя деактивировать себя")

    db.toggle_user_active(user_id)
    token_manager.invalidate_user_sessions(user_id)

    audit_log.log(user.user_id, "TOGGLE_USER", get_client_ip(request), f"User ID: {user_id}")

    return RedirectResponse(url="/admin", status_code=303)


@app.get("/audit", response_class=HTMLResponse)
async def audit_page(request: Request):
    """Журнал аудита"""
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    if not check_permission(user, Permission.VIEW_AUDIT_LOG):
        raise HTTPException(status_code=403, detail="Недостаточно прав")

    db_user = db.get_user_by_id(user.user_id)
    logs = audit_log.get_logs(100)

    return templates.TemplateResponse("audit.html", {
        "request": request,
        "user": db_user,
        "logs": logs
    })


# ============== ЗАПУСК ==============
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)