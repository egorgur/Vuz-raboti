"""
Модуль безопасности - нативная реализация механизмов защиты.
Защита от: перехвата cookies, replay-атак, session hijacking, CSRF, XSS
"""

import os
import time
import hashlib
import hmac
import secrets
import base64
import json
from typing import Optional, Tuple, Dict, Any
from dataclasses import dataclass
from enum import Enum
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend


# ============== КОНФИГУРАЦИЯ ==============
class Config:
    # Секретные ключи (в реальном приложении - из переменных окружения)
    SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))
    ENCRYPTION_KEY = os.environ.get('ENC_KEY', secrets.token_hex(32))

    # Время жизни токена в секундах (короткий TTL для защиты от перехвата)
    TOKEN_TTL = 300  # 5 минут

    # Максимальное количество попыток входа
    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_TIME = 900  # 15 минут блокировки

    # Соль для хеширования паролей
    PASSWORD_SALT_LENGTH = 32
    PASSWORD_ITERATIONS = 100000


# ============== РОЛИ И ПРАВА ==============
class Role(Enum):
    ADMIN = "admin"
    MODERATOR = "moderator"
    USER = "user"


class Permission(Enum):
    # Заметки
    CREATE_NOTE = "create_note"
    READ_OWN_NOTES = "read_own_notes"
    READ_ALL_NOTES = "read_all_notes"
    EDIT_OWN_NOTES = "edit_own_notes"
    EDIT_ALL_NOTES = "edit_all_notes"
    DELETE_OWN_NOTES = "delete_own_notes"
    DELETE_ALL_NOTES = "delete_all_notes"

    # Администрирование
    MANAGE_USERS = "manage_users"
    VIEW_AUDIT_LOG = "view_audit_log"


# Матрица ролей и разрешений (RBAC)
ROLE_PERMISSIONS: Dict[Role, set] = {
    Role.ADMIN: {
        Permission.CREATE_NOTE,
        Permission.READ_OWN_NOTES,
        Permission.READ_ALL_NOTES,
        Permission.EDIT_OWN_NOTES,
        Permission.EDIT_ALL_NOTES,
        Permission.DELETE_OWN_NOTES,
        Permission.DELETE_ALL_NOTES,
        Permission.MANAGE_USERS,
        Permission.VIEW_AUDIT_LOG,
    },
    Role.MODERATOR: {
        Permission.CREATE_NOTE,
        Permission.READ_OWN_NOTES,
        Permission.READ_ALL_NOTES,
        Permission.EDIT_OWN_NOTES,
        Permission.DELETE_OWN_NOTES,
        Permission.VIEW_AUDIT_LOG,
    },
    Role.USER: {
        Permission.CREATE_NOTE,
        Permission.READ_OWN_NOTES,
        Permission.EDIT_OWN_NOTES,
        Permission.DELETE_OWN_NOTES,
    },
}


def has_permission(role: Role, permission: Permission) -> bool:
    """Проверка наличия разрешения у роли"""
    return permission in ROLE_PERMISSIONS.get(role, set())


# ============== КРИПТОГРАФИЧЕСКИЕ ФУНКЦИИ ==============
class CryptoManager:
    """Менеджер криптографических операций"""

    def __init__(self, encryption_key: str, secret_key: str):
        # Деривация ключа шифрования из строки
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'token_encryption_salt',
            iterations=100000,
            backend=default_backend()
        )
        self._enc_key = kdf.derive(encryption_key.encode())
        self._secret_key = secret_key.encode()
        self._aesgcm = AESGCM(self._enc_key)

    def encrypt(self, plaintext: str) -> str:
        """AES-GCM шифрование"""
        nonce = os.urandom(12)
        ciphertext = self._aesgcm.encrypt(nonce, plaintext.encode(), None)
        # Объединяем nonce и шифротекст
        combined = nonce + ciphertext
        return base64.urlsafe_b64encode(combined).decode()

    def decrypt(self, ciphertext: str) -> Optional[str]:
        """AES-GCM дешифрование"""
        try:
            combined = base64.urlsafe_b64decode(ciphertext.encode())
            nonce = combined[:12]
            encrypted_data = combined[12:]
            plaintext = self._aesgcm.decrypt(nonce, encrypted_data, None)
            return plaintext.decode()
        except Exception:
            return None

    def hmac_sign(self, data: str) -> str:
        """HMAC-SHA256 подпись"""
        signature = hmac.new(
            self._secret_key,
            data.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature

    def hmac_verify(self, data: str, signature: str) -> bool:
        """Проверка HMAC-SHA256 подписи"""
        expected = self.hmac_sign(data)
        return hmac.compare_digest(expected, signature)


# ============== ХЕШИРОВАНИЕ ПАРОЛЕЙ ==============
class PasswordManager:
    """Безопасное хеширование паролей с использованием PBKDF2"""

    @staticmethod
    def hash_password(password: str) -> str:
        """Хеширование пароля с солью"""
        salt = os.urandom(Config.PASSWORD_SALT_LENGTH)

        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=Config.PASSWORD_ITERATIONS,
            backend=default_backend()
        )

        key = kdf.derive(password.encode())

        # Формат: salt$hash (оба в base64)
        salt_b64 = base64.b64encode(salt).decode()
        hash_b64 = base64.b64encode(key).decode()

        return f"{salt_b64}${hash_b64}"

    @staticmethod
    def verify_password(password: str, stored_hash: str) -> bool:
        """Проверка пароля"""
        try:
            parts = stored_hash.split('$')
            if len(parts) != 2:
                return False

            salt = base64.b64decode(parts[0])
            stored_key = base64.b64decode(parts[1])

            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=Config.PASSWORD_ITERATIONS,
                backend=default_backend()
            )

            try:
                kdf.verify(password.encode(), stored_key)
                return True
            except Exception:
                return False
        except Exception:
            return False


# ============== ТОКЕНЫ СЕССИИ ==============
@dataclass
class SessionToken:
    """Структура токена сессии"""
    user_id: int
    session_id: str
    created_at: float
    ip_hash: str
    user_agent_hash: str
    nonce: str
    role: str


class TokenManager:
    """Менеджер токенов сессии с защитой от перехвата"""

    def __init__(self, crypto: CryptoManager):
        self.crypto = crypto
        # Хранилище использованных nonce (защита от replay)
        self._used_nonces: Dict[str, float] = {}
        # Активные сессии
        self._active_sessions: Dict[str, Dict] = {}

    def _hash_fingerprint(self, ip: str, user_agent: str) -> Tuple[str, str]:
        """Создание fingerprint клиента"""
        ip_hash = hashlib.sha256(ip.encode()).hexdigest()[:16]
        ua_hash = hashlib.sha256(user_agent.encode()).hexdigest()[:16]
        return ip_hash, ua_hash

    def create_token(self, user_id: int, role: str, ip: str, user_agent: str, session_id: str = None) -> str:
        """
        Создание зашифрованного токена сессии.
        """
        # ИСПРАВЛЕНИЕ: Если session_id передан, используем его (ротация), иначе генерируем новый (логин)
        if session_id is None:
            session_id = secrets.token_hex(16)

        nonce = secrets.token_hex(16)
        ip_hash, ua_hash = self._hash_fingerprint(ip, user_agent)
        created_at = time.time()

        # Сохраняем/Обновляем сессию (ID остается тем же, обновляется время и nonce)
        self._active_sessions[session_id] = {
            'user_id': user_id,
            'role': role,
            'created_at': created_at,
            'ip_hash': ip_hash,
            'ua_hash': ua_hash,
            'last_nonce': nonce
        }


        # Формируем payload токена
        token_data = SessionToken(
            user_id=user_id,
            session_id=session_id,  # Здесь будет использоваться стабильный ID
            created_at=created_at,
            ip_hash=ip_hash,
            user_agent_hash=ua_hash,
            nonce=nonce,
            role=role
        )


        payload = json.dumps({
            'uid': token_data.user_id,
            'sid': token_data.session_id,
            'cat': token_data.created_at,
            'iph': token_data.ip_hash,
            'uah': token_data.user_agent_hash,
            'non': token_data.nonce,
            'rol': token_data.role
        })

        encrypted = self.crypto.encrypt(payload)
        signature = self.crypto.hmac_sign(encrypted)

        return f"{encrypted}.{signature}"

    def validate_token(self, token: str, ip: str, user_agent: str) -> Optional[SessionToken]:
        """
        Валидация токена с проверкой:
        1. Целостности (HMAC)
        2. Расшифровки
        3. TTL
        4. Fingerprint (IP + User-Agent)
        5. Nonce (защита от replay)
        """
        try:
            parts = token.split('.')
            if len(parts) != 2:
                return None

            encrypted, signature = parts

            # Проверка подписи
            if not self.crypto.hmac_verify(encrypted, signature):
                return None

            # Расшифровка
            payload = self.crypto.decrypt(encrypted)
            if not payload:
                return None

            data = json.loads(payload)

            # Восстановление структуры
            token_data = SessionToken(
                user_id=data['uid'],
                session_id=data['sid'],
                created_at=data['cat'],
                ip_hash=data['iph'],
                user_agent_hash=data['uah'],
                nonce=data['non'],
                role=data['rol']
            )

            # Проверка TTL
            if time.time() - token_data.created_at > Config.TOKEN_TTL:
                self._invalidate_session(token_data.session_id)
                return None

            # Проверка fingerprint (защита от кражи cookies)
            current_ip_hash, current_ua_hash = self._hash_fingerprint(ip, user_agent)

            if token_data.ip_hash != current_ip_hash:
                # IP изменился - потенциальная кража cookie!
                self._invalidate_session(token_data.session_id)
                return None

            if token_data.user_agent_hash != current_ua_hash:
                # User-Agent изменился - потенциальная кража cookie!
                self._invalidate_session(token_data.session_id)
                return None

            # Проверка сессии
            session = self._active_sessions.get(token_data.session_id)
            if not session:
                return None

            # Проверка nonce (защита от replay-атаки)
            if token_data.nonce in self._used_nonces:
                # Токен уже использовался! Это replay-атака!
                self._invalidate_session(token_data.session_id)
                return None

            # Помечаем nonce как использованный
            self._used_nonces[token_data.nonce] = time.time()
            self._cleanup_old_nonces()

            return token_data

        except Exception:
            return None

    def refresh_token(self, old_token: str, ip: str, user_agent: str) -> Optional[str]:
        """
        Ротация токена - создание нового токена после каждого запроса.
        Это делает украденный токен одноразовым.
        """
        token_data = self.validate_token(old_token, ip, user_agent)
        if not token_data:
            return None

        return self.create_token(
            token_data.user_id,
            token_data.role,
            ip,
            user_agent
        )

    def _invalidate_session(self, session_id: str):
        """Инвалидация сессии"""
        self._active_sessions.pop(session_id, None)

    def invalidate_user_sessions(self, user_id: int):
        """Инвалидация всех сессий пользователя"""
        to_remove = [
            sid for sid, data in self._active_sessions.items()
            if data['user_id'] == user_id
        ]
        for sid in to_remove:
            self._invalidate_session(sid)

    def _cleanup_old_nonces(self):
        """Очистка старых nonce"""
        current_time = time.time()
        self._used_nonces = {
            nonce: timestamp
            for nonce, timestamp in self._used_nonces.items()
            if current_time - timestamp < Config.TOKEN_TTL * 2
        }


# ============== CSRF ЗАЩИТА ==============
class CSRFProtection:
    """Защита от CSRF-атак (Double Submit Cookie pattern)"""

    def __init__(self, crypto: CryptoManager):
        self.crypto = crypto

    def generate_token(self, session_id: str) -> str:
        """Генерация CSRF-токена привязанного к сессии"""
        data = f"{session_id}|{time.time()}|{secrets.token_hex(16)}"
        encrypted = self.crypto.encrypt(data)
        signature = self.crypto.hmac_sign(encrypted)
        return f"{encrypted}.{signature}"

    def validate_token(self, csrf_token: str, session_id: str) -> bool:
        """Валидация CSRF-токена"""
        try:
            parts = csrf_token.split('.')
            if len(parts) != 2:
                return False

            encrypted, signature = parts

            if not self.crypto.hmac_verify(encrypted, signature):
                return False

            data = self.crypto.decrypt(encrypted)
            if not data:
                return False

            parts = data.split('|')
            if len(parts) != 3:
                return False

            token_session_id, timestamp, _ = parts

            # Проверка привязки к сессии
            if token_session_id != session_id:
                return False

            # Проверка времени жизни (30 минут для форм)
            if time.time() - float(timestamp) > 1800:
                return False

            return True

        except Exception:
            return False


# ============== ЗАЩИТА ОТ BRUTE FORCE ==============
class BruteForceProtection:
    """Защита от подбора паролей"""

    def __init__(self):
        self._attempts: Dict[str, list] = {}  # ip -> [timestamps]
        self._lockouts: Dict[str, float] = {}  # ip -> lockout_until

    def is_locked(self, ip: str) -> bool:
        """Проверка блокировки IP"""
        if ip in self._lockouts:
            if time.time() < self._lockouts[ip]:
                return True
            else:
                del self._lockouts[ip]
        return False

    def record_attempt(self, ip: str, success: bool):
        """Запись попытки входа"""
        current_time = time.time()

        if success:
            # Успешный вход - сброс счётчика
            self._attempts.pop(ip, None)
            return

        # Неудачная попытка
        if ip not in self._attempts:
            self._attempts[ip] = []

        # Удаляем старые попытки (старше 15 минут)
        self._attempts[ip] = [
            t for t in self._attempts[ip]
            if current_time - t < Config.LOCKOUT_TIME
        ]

        self._attempts[ip].append(current_time)

        # Проверка на блокировку
        if len(self._attempts[ip]) >= Config.MAX_LOGIN_ATTEMPTS:
            self._lockouts[ip] = current_time + Config.LOCKOUT_TIME
            self._attempts.pop(ip, None)

    def get_remaining_attempts(self, ip: str) -> int:
        """Получение оставшихся попыток"""
        if ip not in self._attempts:
            return Config.MAX_LOGIN_ATTEMPTS
        return max(0, Config.MAX_LOGIN_ATTEMPTS - len(self._attempts[ip]))


# ============== XSS ЗАЩИТА ==============
class XSSProtection:
    """Защита от XSS-атак"""

    @staticmethod
    def sanitize(text: str) -> str:
        """Экранирование HTML-символов"""
        if not text:
            return ""

        replacements = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '/': '&#x2F;',
        }

        result = text
        for char, escape in replacements.items():
            result = result.replace(char, escape)

        return result

    @staticmethod
    def sanitize_dict(data: dict) -> dict:
        """Рекурсивная санитизация словаря"""
        sanitized = {}
        for key, value in data.items():
            if isinstance(value, str):
                sanitized[key] = XSSProtection.sanitize(value)
            elif isinstance(value, dict):
                sanitized[key] = XSSProtection.sanitize_dict(value)
            elif isinstance(value, list):
                sanitized[key] = [
                    XSSProtection.sanitize(v) if isinstance(v, str)
                    else XSSProtection.sanitize_dict(v) if isinstance(v, dict)
                    else v
                    for v in value
                ]
            else:
                sanitized[key] = value
        return sanitized


# ============== АУДИТ ==============
class AuditLog:
    """Журнал аудита действий"""

    def __init__(self):
        self._logs: list = []

    def log(self, user_id: Optional[int], action: str, ip: str,
            details: str = "", success: bool = True):
        """Запись действия в аудит"""
        self._logs.append({
            'timestamp': time.time(),
            'user_id': user_id,
            'action': action,
            'ip': ip,
            'details': details,
            'success': success
        })

    def get_logs(self, limit: int = 100) -> list:
        """Получение последних записей"""
        return sorted(self._logs, key=lambda x: x['timestamp'], reverse=True)[:limit]


# ============== ИНИЦИАЛИЗАЦИЯ ==============
crypto_manager = CryptoManager(Config.ENCRYPTION_KEY, Config.SECRET_KEY)
password_manager = PasswordManager()
token_manager = TokenManager(crypto_manager)
csrf_protection = CSRFProtection(crypto_manager)
brute_force_protection = BruteForceProtection()
xss_protection = XSSProtection()
audit_log = AuditLog()