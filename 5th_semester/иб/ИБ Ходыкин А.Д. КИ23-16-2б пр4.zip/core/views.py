from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
import random
import hashlib

from .forms import RegisterForm, LoginForm
from .models import Role, UserProfile, Request


# ---------- РЕГИСТРАЦИЯ ----------
def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password1'])
            user.save()

            role = Role.objects.get(name='User')
            UserProfile.objects.create(user=user, role=role)

            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'register.html', {'form': form})


# ---------- ВХОД ----------
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)   # СОЗДАЁТСЯ SESSION + COOKIE
            return redirect('dashboard')
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})


# ---------- ВЫХОД ----------
@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


# ---------- ГЛАВНАЯ СТРАНИЦА ----------
@login_required
def dashboard_view(request):
    profile = request.user.userprofile

    if profile.role.name == 'Admin' or profile.role.name == 'Manager':
        requests = Request.objects.all()
    else:
        requests = Request.objects.filter(created_by=request.user)

    return render(request, 'dashboard.html', {
        'role': profile.role.name,
        'requests': requests
    })



@login_required
def dh_demo_view(request):
    # публичные параметры
    p = 23
    g = 5

    # секрет сервера
    b = random.randint(2, 10)
    B = pow(g, b, p)

    if request.method == 'POST':
        A = int(request.POST.get('A'))
        shared_key = pow(A, b, p)

        message = "secret data"
        hashed = hashlib.sha256((message + str(shared_key)).encode()).hexdigest()

        return render(request, 'dh.html', {
            'p': p,
            'g': g,
            'B': B,
            'shared_key': shared_key,
            'hash': hashed
        })

    return render(request, 'dh.html', {
        'p': p,
        'g': g,
        'B': B
    })