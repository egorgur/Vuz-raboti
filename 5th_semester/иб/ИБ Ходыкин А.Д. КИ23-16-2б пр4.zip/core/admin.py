from django.contrib import admin

from django.contrib import admin
from .models import Role, UserProfile, Request

admin.site.register(Role)
admin.site.register(UserProfile)
admin.site.register(Request)