"""
Точка входа приложения NewNote.

Аспекты безопасности:
  - Модульность (№1): приложение собрано из независимых модулей-пакетов
    (auth/, notes/, interfaces/, admin/, security/), каждый из которых
    изолирован по ответственности и взаимодействует с остальными только
    через явные интерфейсы;
  - Контейнеризация (№2): приложение запускается в Docker-контейнере
    с минимальными привилегиями (см. Dockerfile, docker-compose.yml);
  - RBAC (№3): ролевая модель доступа, см. пакет security/.
"""

from fastapi import FastAPI
from database import Base, engine
from auth.router import router as auth_router
from notes.router import router as notes_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="NewNote",
    description="Note-taking app — SOLID + components + security (modularity, containerization, RBAC)",
)

# Модульность (№1): каждый модуль подключается как независимый роутер
app.include_router(auth_router,  prefix="/auth",  tags=["auth"])
app.include_router(notes_router, prefix="/notes", tags=["notes"])
