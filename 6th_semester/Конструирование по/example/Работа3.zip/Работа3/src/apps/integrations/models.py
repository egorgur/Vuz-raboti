from django.db import models

from src.apps.organizations.models import Office


class MarketplacePlatform(models.TextChoices):
    AVITO = "avito", "Avito"
    OZON = "ozon", "Ozon"
    WILDBERRIES = "wildberries", "Wildberries"


class ConnectionStatus(models.TextChoices):
    ACTIVE = "active", "Active"
    TOKEN_ERROR = "token_error", "Token error"
    DISCONNECTED = "disconnected", "Disconnected"


class StoreConnection(models.Model):
    """Подключение кабинета маркетплейса к офису (FRQ-4, NFRQ-5 — поле для шифротекста)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="store_connections",
    )
    platform = models.CharField(max_length=32, choices=MarketplacePlatform)
    encrypted_api_payload = models.BinaryField(null=True, blank=True)
    status = models.CharField(
        max_length=32,
        choices=ConnectionStatus,
        default=ConnectionStatus.DISCONNECTED,
    )

    class Meta:
        db_table = "mp_integrations_store_connection"
        constraints = [
            models.UniqueConstraint(
                fields=["office", "platform"],
                name="uniq_office_marketplace_platform",
            ),
        ]
