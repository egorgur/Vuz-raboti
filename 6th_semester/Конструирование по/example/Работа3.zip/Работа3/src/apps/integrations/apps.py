from django.apps import AppConfig


class IntegrationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.integrations"
    label = "mp_integrations"
    verbose_name = "MarketPulse Marketplace Integrations"
