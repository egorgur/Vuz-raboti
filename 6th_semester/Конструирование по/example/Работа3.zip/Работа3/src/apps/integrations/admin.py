from django.contrib import admin

from src.apps.integrations.models import StoreConnection


@admin.register(StoreConnection)
class StoreConnectionAdmin(admin.ModelAdmin):
    list_display = ("office", "platform", "status")
