from django.conf import settings
from django.db import models

from src.apps.integrations.models import StoreConnection
from src.apps.organizations.models import Office


class DefaultPeriod(models.TextChoices):
    DAY = "day", "Day"
    WEEK = "week", "Week"
    MONTH = "month", "Month"


class ReportTemplate(models.Model):
    """Шаблон отчёта по данным маркетплейсов (FRQ-5)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="report_templates",
    )
    store_connection = models.ForeignKey(
        StoreConnection,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="report_templates",
    )
    name = models.CharField(max_length=255)
    default_period = models.CharField(
        max_length=16,
        choices=DefaultPeriod,
        default=DefaultPeriod.MONTH,
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_report_templates",
    )

    class Meta:
        db_table = "mp_analytics_report_template"


class ReportFormula(models.Model):
    """Пользовательская формула в составе шаблона (FRQ-5)."""

    template = models.ForeignKey(
        ReportTemplate,
        on_delete=models.CASCADE,
        related_name="formulas",
    )
    name = models.CharField(max_length=128)
    expression = models.TextField()

    class Meta:
        db_table = "mp_analytics_report_formula"


class Dashboard(models.Model):
    """Дашборд офиса (FRQ-6)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="dashboards",
    )
    name = models.CharField(max_length=255)

    class Meta:
        db_table = "mp_analytics_dashboard"


class DashboardBlock(models.Model):
    """Блок дашборда, привязанный к шаблону отчёта (FRQ-6; layout — заготовка под drag-and-drop)."""

    dashboard = models.ForeignKey(
        Dashboard,
        on_delete=models.CASCADE,
        related_name="blocks",
    )
    template = models.ForeignKey(
        ReportTemplate,
        on_delete=models.CASCADE,
        related_name="dashboard_blocks",
    )
    layout = models.JSONField(default=dict, blank=True)

    class Meta:
        db_table = "mp_analytics_dashboard_block"
