from django.apps import AppConfig


class AnalyticsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.analytics"
    label = "mp_analytics"
    verbose_name = "MarketPulse Analytics"
