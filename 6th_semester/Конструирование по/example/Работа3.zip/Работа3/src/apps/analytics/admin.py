from django.contrib import admin

from src.apps.analytics.models import Dashboard, DashboardBlock, ReportFormula, ReportTemplate


class ReportFormulaInline(admin.TabularInline):
    model = ReportFormula
    extra = 0


@admin.register(ReportTemplate)
class ReportTemplateAdmin(admin.ModelAdmin):
    list_display = ("name", "office", "default_period")
    inlines = [ReportFormulaInline]


class DashboardBlockInline(admin.TabularInline):
    model = DashboardBlock
    extra = 0


@admin.register(Dashboard)
class DashboardAdmin(admin.ModelAdmin):
    list_display = ("name", "office")
    inlines = [DashboardBlockInline]


@admin.register(DashboardBlock)
class DashboardBlockAdmin(admin.ModelAdmin):
    list_display = ("dashboard", "template")
