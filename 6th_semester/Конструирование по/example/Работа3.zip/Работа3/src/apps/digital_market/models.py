from django.conf import settings
from django.db import models

from src.apps.analytics.models import Dashboard
from src.apps.organizations.models import Office
from src.apps.publisher.models import PublicationStrategy


class CatalogAssetType(models.TextChoices):
    DASHBOARD = "dashboard", "Dashboard"
    STRATEGY = "strategy", "Strategy"


class CatalogSubmissionStatus(models.TextChoices):
    DRAFT = "draft", "Draft"
    PENDING = "pending", "Pending review"
    PUBLISHED = "published", "Published"
    REJECTED = "rejected", "Rejected"


class CatalogSubmission(models.Model):
    """Заявка на публикацию цифрового актива в каталоге (FRQ-9)."""

    submitter = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="catalog_submissions",
    )
    office = models.ForeignKey(
        Office,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="catalog_submissions",
    )
    asset_type = models.CharField(max_length=32, choices=CatalogAssetType)
    title = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=12, decimal_places=2)
    category = models.CharField(max_length=128)
    status = models.CharField(
        max_length=32,
        choices=CatalogSubmissionStatus,
        default=CatalogSubmissionStatus.DRAFT,
    )
    prohibited_content_detected = models.BooleanField(default=False)
    dashboard = models.ForeignKey(
        Dashboard,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="catalog_submissions",
    )
    strategy = models.ForeignKey(
        PublicationStrategy,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="catalog_submissions",
    )

    class Meta:
        db_table = "mp_digital_market_catalog_submission"


class CatalogScreenshot(models.Model):
    """Скриншоты к заявке (FRQ-9)."""

    submission = models.ForeignKey(
        CatalogSubmission,
        on_delete=models.CASCADE,
        related_name="screenshots",
    )
    image = models.FileField(upload_to="mp/catalog_screenshots/")

    class Meta:
        db_table = "mp_digital_market_catalog_screenshot"
