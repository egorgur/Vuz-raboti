from django.contrib import admin

from src.apps.digital_market.models import CatalogScreenshot, CatalogSubmission


class CatalogScreenshotInline(admin.TabularInline):
    model = CatalogScreenshot
    extra = 0


@admin.register(CatalogSubmission)
class CatalogSubmissionAdmin(admin.ModelAdmin):
    list_display = ("title", "submitter", "asset_type", "status")
    inlines = [CatalogScreenshotInline]
