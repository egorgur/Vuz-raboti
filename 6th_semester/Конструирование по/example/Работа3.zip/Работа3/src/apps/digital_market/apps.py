from django.apps import AppConfig


class DigitalMarketConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.digital_market"
    label = "mp_digital_market"
    verbose_name = "MarketPulse Digital Catalog"
