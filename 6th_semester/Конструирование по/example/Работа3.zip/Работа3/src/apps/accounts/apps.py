from django.apps import AppConfig


class AccountsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.accounts"
    label = "mp_accounts"
    verbose_name = "MarketPulse Accounts"
