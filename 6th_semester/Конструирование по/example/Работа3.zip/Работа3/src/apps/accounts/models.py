from django.conf import settings
from django.db import models


class UserRole(models.TextChoices):
    SELLER = "seller", "Seller"
    MODERATOR = "moderator", "Moderator"


class Profile(models.Model):
    """Расширение пользователя: роль в продукте и реферальный код (FRQ-1, FRQ-7)."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="mp_profile",
    )
    role = models.CharField(max_length=32, choices=UserRole, default=UserRole.SELLER)
    referral_code = models.CharField(max_length=64, unique=True, null=True, blank=True)

    class Meta:
        db_table = "mp_accounts_profile"
