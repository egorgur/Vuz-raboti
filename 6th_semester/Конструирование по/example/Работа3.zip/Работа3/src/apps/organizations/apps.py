from django.apps import AppConfig


class OrganizationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.organizations"
    label = "mp_organizations"
    verbose_name = "MarketPulse Organizations"
