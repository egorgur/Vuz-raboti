from django.contrib import admin

from src.apps.organizations.models import Office, OfficeMembership


class OfficeMembershipInline(admin.TabularInline):
    model = OfficeMembership
    extra = 0


@admin.register(Office)
class OfficeAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "inn")
    inlines = [OfficeMembershipInline]


@admin.register(OfficeMembership)
class OfficeMembershipAdmin(admin.ModelAdmin):
    list_display = ("office", "user", "permission")
