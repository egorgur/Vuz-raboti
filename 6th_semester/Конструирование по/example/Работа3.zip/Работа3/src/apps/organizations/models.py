from django.conf import settings
from django.db import models


class OfficePermission(models.TextChoices):
    FULL = "full", "Full access"
    ANALYTICS = "analytics", "Analytics"
    STORES = "stores", "Stores"
    INVITE_USERS = "invite_users", "Invite users"
    READONLY = "readonly", "Read only"


class Office(models.Model):
    """Организация (офис): FRQ-3."""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="owned_offices",
    )
    name = models.CharField(max_length=255)
    inn = models.CharField(max_length=32, blank=True)
    logo = models.FileField(upload_to="mp/office_logos/", blank=True, null=True)

    class Meta:
        db_table = "mp_organizations_office"


class OfficeMembership(models.Model):
    """Участник офиса и уровень доступа (FRQ-3)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="memberships",
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="office_memberships",
    )
    permission = models.CharField(max_length=32, choices=OfficePermission)

    class Meta:
        db_table = "mp_organizations_membership"
        constraints = [
            models.UniqueConstraint(fields=["office", "user"], name="uniq_office_user_membership"),
        ]
