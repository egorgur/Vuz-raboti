from django.apps import AppConfig


class ModerationConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.moderation"
    label = "mp_moderation"
    verbose_name = "MarketPulse Moderation"
