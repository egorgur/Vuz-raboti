from django.conf import settings
from django.db import models

from src.apps.digital_market.models import CatalogSubmission


class ModerationDecision(models.TextChoices):
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"


class ModerationReview(models.Model):
    """Решение модератора по заявке (FRQ-10)."""

    submission = models.ForeignKey(
        CatalogSubmission,
        on_delete=models.CASCADE,
        related_name="moderation_reviews",
    )
    moderator = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="moderation_reviews",
    )
    decision = models.CharField(max_length=32, choices=ModerationDecision)
    comment = models.TextField(blank=True)
    reviewed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "mp_moderation_review"
        ordering = ["-reviewed_at"]
