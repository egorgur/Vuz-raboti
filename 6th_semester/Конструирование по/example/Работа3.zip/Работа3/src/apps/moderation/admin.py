from django.contrib import admin

from src.apps.moderation.models import ModerationReview


@admin.register(ModerationReview)
class ModerationReviewAdmin(admin.ModelAdmin):
    list_display = ("submission", "moderator", "decision", "reviewed_at")
