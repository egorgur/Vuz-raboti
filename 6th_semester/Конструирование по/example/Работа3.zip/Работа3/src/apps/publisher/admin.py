from django.contrib import admin

from src.apps.publisher.models import (
    ListingList,
    ListingListItem,
    ListingTemplate,
    PublicationStrategy,
    StrategyAutoloadLink,
)


class ListingListItemInline(admin.TabularInline):
    model = ListingListItem
    extra = 0


@admin.register(ListingTemplate)
class ListingTemplateAdmin(admin.ModelAdmin):
    list_display = ("name", "office")


@admin.register(ListingList)
class ListingListAdmin(admin.ModelAdmin):
    list_display = ("name", "office")
    inlines = [ListingListItemInline]


class StrategyAutoloadLinkInline(admin.TabularInline):
    model = StrategyAutoloadLink
    extra = 0


@admin.register(PublicationStrategy)
class PublicationStrategyAdmin(admin.ModelAdmin):
    list_display = ("name", "office")
    inlines = [StrategyAutoloadLinkInline]
