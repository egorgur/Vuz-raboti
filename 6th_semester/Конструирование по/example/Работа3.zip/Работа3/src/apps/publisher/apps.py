from django.apps import AppConfig


class PublisherConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.publisher"
    label = "mp_publisher"
    verbose_name = "MarketPulse Listing Publisher"
