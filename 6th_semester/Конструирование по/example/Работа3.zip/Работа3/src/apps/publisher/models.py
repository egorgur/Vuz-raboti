from django.db import models

from src.apps.organizations.models import Office


class ListingTemplate(models.Model):
    """Шаблон объявления / автозагрузки (FRQ-8)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="listing_templates",
    )
    name = models.CharField(max_length=255)
    config = models.JSONField(default=dict, blank=True)

    class Meta:
        db_table = "mp_publisher_listing_template"


class ListingList(models.Model):
    """Список объявлений (FRQ-8)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="listing_lists",
    )
    name = models.CharField(max_length=255)

    class Meta:
        db_table = "mp_publisher_listing_list"


class ListingListItem(models.Model):
    """Позиция в списке: связь список с шаблон."""

    listing_list = models.ForeignKey(
        ListingList,
        on_delete=models.CASCADE,
        related_name="items",
    )
    template = models.ForeignKey(
        ListingTemplate,
        on_delete=models.CASCADE,
        related_name="list_items",
    )
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "mp_publisher_listing_list_item"
        constraints = [
            models.UniqueConstraint(
                fields=["listing_list", "template"],
                name="uniq_listing_list_template",
            ),
        ]


class PublicationStrategy(models.Model):
    """Стратегия публикации (FRQ-8)."""

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="publication_strategies",
    )
    name = models.CharField(max_length=255)

    class Meta:
        db_table = "mp_publisher_publication_strategy"


class StrategyAutoloadLink(models.Model):
    """Подключение стратегии к списку автозагрузки (FRQ-8)."""

    strategy = models.ForeignKey(
        PublicationStrategy,
        on_delete=models.CASCADE,
        related_name="autoload_links",
    )
    listing_list = models.ForeignKey(
        ListingList,
        on_delete=models.CASCADE,
        related_name="strategy_links",
    )

    class Meta:
        db_table = "mp_publisher_strategy_autoload_link"
        constraints = [
            models.UniqueConstraint(
                fields=["strategy", "listing_list"],
                name="uniq_strategy_listing_list",
            ),
        ]
