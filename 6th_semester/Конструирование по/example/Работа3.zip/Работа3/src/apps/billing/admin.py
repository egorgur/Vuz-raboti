from django.contrib import admin

from src.apps.billing.models import OfficeSubscription, SubscriptionPlan


@admin.register(SubscriptionPlan)
class SubscriptionPlanAdmin(admin.ModelAdmin):
    list_display = ("slug", "name", "max_stores", "max_members")


@admin.register(OfficeSubscription)
class OfficeSubscriptionAdmin(admin.ModelAdmin):
    list_display = ("office", "plan")
