from django.apps import AppConfig


class BillingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.billing"
    label = "mp_billing"
    verbose_name = "MarketPulse Billing"
