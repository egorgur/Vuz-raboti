from django.db import models

from src.apps.organizations.models import Office


class SubscriptionPlan(models.Model):
    """Тариф: лимиты магазинов и участников (FRQ-3, бизнес-требования по тарифам)."""

    slug = models.SlugField(unique=True)
    name = models.CharField(max_length=128)
    max_stores = models.PositiveIntegerField(default=1)
    max_members = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = "mp_billing_subscription_plan"


class OfficeSubscription(models.Model):
    """Привязка офиса к тарифу."""

    office = models.OneToOneField(
        Office,
        on_delete=models.CASCADE,
        related_name="subscription",
    )
    plan = models.ForeignKey(
        SubscriptionPlan,
        on_delete=models.PROTECT,
        related_name="office_subscriptions",
    )

    class Meta:
        db_table = "mp_billing_office_subscription"
