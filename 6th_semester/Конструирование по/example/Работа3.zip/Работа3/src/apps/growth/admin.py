from django.contrib import admin

from src.apps.growth.models import BonusLedgerEntry, PromoCode, ReferralConversion


@admin.register(ReferralConversion)
class ReferralConversionAdmin(admin.ModelAdmin):
    list_display = ("referrer", "referee", "first_paid_at")


@admin.register(PromoCode)
class PromoCodeAdmin(admin.ModelAdmin):
    list_display = ("code", "owner", "is_redeemed")


@admin.register(BonusLedgerEntry)
class BonusLedgerEntryAdmin(admin.ModelAdmin):
    list_display = ("user", "amount", "created_at")
