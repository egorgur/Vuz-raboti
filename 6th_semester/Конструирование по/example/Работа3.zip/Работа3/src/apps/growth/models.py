from django.conf import settings
from django.db import models


class ReferralConversion(models.Model):
    """Связь пригласивший - приглашённый (FRQ-7)."""

    referrer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="referrals_sent",
    )
    referee = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="referral_attribution",
    )
    first_paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "mp_growth_referral_conversion"


class PromoCode(models.Model):
    """Промокод, выдаваемый в рамках реферальной программы (FRQ-7)."""

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="owned_promo_codes",
    )
    code = models.CharField(max_length=64, unique=True)
    is_redeemed = models.BooleanField(default=False)

    class Meta:
        db_table = "mp_growth_promo_code"


class BonusLedgerEntry(models.Model):
    """История начислений бонусов пользователю (FRQ-7)."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="bonus_ledger_entries",
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    description = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "mp_growth_bonus_ledger_entry"
        ordering = ["-created_at"]
