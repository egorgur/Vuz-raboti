from django.apps import AppConfig


class GrowthConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "src.apps.growth"
    label = "mp_growth"
    verbose_name = "MarketPulse Growth & Referrals"
