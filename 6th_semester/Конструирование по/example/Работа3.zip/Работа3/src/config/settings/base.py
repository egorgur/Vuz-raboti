DEBUG = False
SECRET_KEY = NotImplemented

ALLOWED_HOSTS: list[str] = ["localhost", "127.0.0.1"]
CSRF_TRUSTED_ORIGIN: list[str] = []

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Third party
    #   "some_third_party",
    # MarketPulse (связи доменных моделей; бизнес-логика не реализована)
    "src.apps.accounts.apps.AccountsConfig",
    "src.apps.organizations.apps.OrganizationsConfig",
    "src.apps.billing.apps.BillingConfig",
    "src.apps.integrations.apps.IntegrationsConfig",
    "src.apps.analytics.apps.AnalyticsConfig",
    "src.apps.growth.apps.GrowthConfig",
    "src.apps.publisher.apps.PublisherConfig",
    "src.apps.digital_market.apps.DigitalMarketConfig",
    "src.apps.moderation.apps.ModerationConfig",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "src.config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "src.config.wsgi.application"

# !!ATTENTION!!
# DATABASE SETTINGS are set in local/ settings folders.
DATABASES = {}

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"  # type: ignore # noqa: F821

STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"  # type: ignore # noqa: F821

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
