"""
Django Rest Framework configuration.
"""
