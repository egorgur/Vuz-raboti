from abc import ABC, abstractmethod
from typing import Protocol
from datetime import datetime

from src.apps.integrations.dto import Order, Product, StockItem
from src.apps.integrations.models import MarketplacePlatform


# class MarketplaceClient(Protocol):
class MarketplaceClient(ABC):
    """Единый интерфейс для всех маркетплейсов"""

    def __init__(self, platform_name):
        self.platform_name = platform_name

    @property
    def platform(self) -> str:
        return self.platform_name

    @platform.setter
    def platform(self, val):
        self.platform_name = str(val)

    @abstractmethod
    def get_orders(self, since: datetime | None = None, status: str | None = None) -> list[Order]: ...
    @abstractmethod
    def get_stock(self, sku: str | None = None) -> list[StockItem]: ...
    @abstractmethod
    def update_stock(self, sku: str, quantity: int, warehouse_id: str | None = None) -> bool: ...
    @abstractmethod
    def update_product_card(self, card: Product) -> bool: ...
