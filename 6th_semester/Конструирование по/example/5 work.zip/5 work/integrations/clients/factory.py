from __future__ import annotations

from typing import Type

from src.apps.integrations.clients.base import MarketplaceClient
from src.apps.integrations.clients.creators import OzonClientCreator, WildberriesClientCreator, AvitoClientCreator
from src.apps.integrations.clients.decorators import apply_decorators
from src.apps.integrations.clients.interface import MarketplaceClientCreator
from src.apps.integrations.models import (
    ConnectionStatus,
    MarketplacePlatform,
    StoreConnection,
)

class MarketplaceClientFactory:
    """
    Фабрика клиентов маркетплейсов.
    Является главной точкой входа для получения готового клиента.
    """

    # ====================== Регистрация creators ======================
    _CREATORS: dict[str, Type[MarketplaceClientCreator]] = {
        MarketplacePlatform.OZON: OzonClientCreator,
        MarketplacePlatform.WILDBERRIES: WildberriesClientCreator,
        MarketplacePlatform.Avito: AvitoClientCreator,
    }

    @classmethod
    def _get_creator(cls, connection: StoreConnection) -> MarketplaceClientCreator:
        if connection.platform not in cls._CREATORS:
            raise ValueError(
                f"Creator для платформы '{connection.get_platform_display()}' "
                f"не зарегистрирован в MarketplaceClientFactory."
            )
        creator_cls = cls._CREATORS[connection.platform]
        return creator_cls()

    @classmethod
    def get_client(cls, connection: StoreConnection) -> MarketplaceClient:
        """
        Главный метод фабрики — возвращает полностью готовый клиент
        с применёнными декораторами.
        """
        try:
            creator = cls._get_creator(connection)
            client = creator.factory_method(connection)
        except ValueError as e:
            # Проблемы с токенами/credentials
            connection.status = ConnectionStatus.TOKEN_ERROR
            connection.save(update_fields=["status"])
            raise ValueError(f"Ошибка credentials для {connection.platform}: {e}") from e

        except Exception as e:
            connection.status = ConnectionStatus.DISCONNECTED
            connection.save(update_fields=["status"])
            raise RuntimeError(f"Не удалось создать клиент для {connection.platform}") from e

        # Применяем декораторы
        return apply_decorators(client, connection)


def get_marketplace_client(connection: StoreConnection) -> MarketplaceClient:
    """Удобная функция-обёртка над классом-фабрикой"""
    return MarketplaceClientFactory.get_client(connection)
