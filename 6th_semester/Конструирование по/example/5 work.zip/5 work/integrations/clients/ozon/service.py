import requests
from typing import Any, Dict, List, Optional, TypedDict

from src.apps.integrations.dto import Product


class WithQuantDict(TypedDict):
    created: bool
    exists: bool


class ProductFilter(TypedDict, total=False):
    offer_id: List[str]
    product_id: List[str]
    visibility: str
    with_quant: WithQuantDict


class OzonRawService:
    BASE_URL = "https://api-seller.ozon.ru"

    def __init__(self, client_id: str, api_key: str):
        self.client_id = client_id
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({"Client-Id": client_id, "Api-Key": api_key, "Content-Type": "application/json"})

    def _post(self, endpoint: str, json_data: Dict[str, Any]) -> Dict:
        response = self.session.post(f"{self.BASE_URL}{endpoint}", json=json_data)
        response.raise_for_status()
        return response.json()

    def get_stocks(
        self,
        filter_data: ProductFilter,  # Обязательный аргумент переносим вперед
        limit: int = 100,
        cursor: Optional[str] = None,
    ) -> Dict:
        """Получить остатки (v4)"""

        # В v4 API Ozon ожидает структуру {"filter": {...}, "limit": 100}
        body = {"filter": filter_data, "limit": limit}

        if cursor:
            body["cursor"] = cursor

        return self._post("/v4/product/info/stocks", body)

    def update_stocks(self, stocks: list[Dict]) -> Dict:
        """Обновить остатки (v2)"""
        return self._post("/v2/products/stocks", {"stocks": stocks})

    def update_product(self, product: Product) -> Dict:
        """Создать/Обновить продукт (v2)"""

        return self._post("/v3/product/import", product.asdict())
