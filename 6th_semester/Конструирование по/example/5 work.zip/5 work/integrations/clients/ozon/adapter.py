from datetime import datetime
from typing import List

from src.apps.integrations.clients.base import MarketplaceClient
from src.apps.integrations.dto import Order, OrderItem, Product, StockItem
from src.apps.integrations.models import MarketplacePlatform, StoreConnection

from .service import OzonRawService


class OzonClientAdapter(MarketplaceClient):
    """Тонкий адаптер — переводит специфичный API Ozon в общий интерфейс"""

    _platform = MarketplacePlatform.OZON

    def __init__(self, raw_client: OzonRawService):
        self.raw = raw_client  # передаем ссылку на сервис в конструкторе адаптера
    
    @classmethod
    def create_from_connection(cls, connection: StoreConnection) -> "OzonClientAdapter":
        """Фабричный метод — расшифровывает credentials и создаёт клиент"""
        if not connection.encrypted_credentials:
            raise ValueError("Нет учётных данных для Ozon")

        credentials = decrypt_credentials(connection.encrypted_credentials)

        raw_client = OzonRawService(client_id=credentials["client_id"], api_key=credentials["api_key"])
        return cls(raw_client)

    def get_orders(self, since: datetime | None = None, status: str | None = None) -> List[Order]:
        raw_data = self.raw.get_postings_unfulfilled()

        orders = []
        for posting in raw_data.get("result", {}).get("postings", []):
            items = []
            for item in posting.get("products", []):
                items.append(
                    OrderItem(
                        sku=item["offer_id"],
                        quantity=item["quantity"],
                        price=int(item["price"] * 100),  # приводим к копейкам
                        name=item.get("name", ""),
                    )
                )

            orders.append(
                Order(
                    order_id=f"ozon_{posting['posting_number']}",
                    platform_order_id=posting["posting_number"],
                    platform=self.platform,
                    status=posting["status"],
                    items=items,
                    created_at=datetime.fromisoformat(posting["created_at"].replace("Z", "+00:00")),
                    customer_name=posting.get("customer", {}).get("name"),
                )
            )

        return orders

    def update_stock(self, sku: str, quantity: int, warehouse_id: str | None = None) -> bool:
        payload = [{"offer_id": sku, "stock": quantity, "warehouse_id": warehouse_id}]
        response = self.raw.update_stocks(payload)
        # Ozon возвращает success в большинстве случаев при 200 OK
        return bool(response.get("result", False))

    def check_connection(self) -> bool:
        try:
            # Простая проверка — пытаемся получить список заказов с лимитом 1
            self.raw.get_postings_unfulfilled(limit=1)
            return True
        except Exception:
            return False

    def get_stock(self, sku: str | None = None) -> list[StockItem]:
        filter = OzonRawService.Filter(offer_id=[sku], visibility="ALL", with_quant={"created": True, "exists": True})

        response = self.raw.get_stocks(filter=filter)

        return [
            StockItem(sku=item["offer_id"], quantity=item["stocks"], warehouse_id=item["product_id"])
            for item in response.get("items", {})
        ]

    def update_product_card(self, card: Product) -> bool:
        return self.raw.update_product(card)


def decrypt_credentials():
    pass
