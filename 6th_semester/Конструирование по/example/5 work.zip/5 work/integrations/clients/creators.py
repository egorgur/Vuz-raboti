from __future__ import annotations

from src.apps.integrations.clients.base import MarketplaceClient
from src.apps.integrations.clients.interface import MarketplaceClientCreator
from src.apps.integrations.clients.ozon.adapter import OzonClientAdapter
from src.apps.integrations.models import StoreConnection


class OzonClientCreator(MarketplaceClientCreator):
    """Concrete Creator for Ozon adapter."""

    def factory_method(self, connection: StoreConnection) -> MarketplaceClient:
        return OzonClientAdapter.create_from_connection(connection)


class WildberriesClientCreator(MarketplaceClientCreator):
    """Concrete Creator for Wildberries adapter."""

    def factory_method(self, connection: StoreConnection) -> MarketplaceClient:
        raise NotImplementedError("Wildberries adapter is not implemented yet")

class AvitoClientCreator(MarketplaceClientCreator):
    """Concrete Creator for Avito adapter."""

    def factory_method(self, connection: StoreConnection) -> MarketplaceClient:
        raise NotImplementedError("Avito adapter is not implemented yet")

