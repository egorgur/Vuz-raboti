from __future__ import annotations

from abc import ABC, abstractmethod

from src.apps.integrations.clients.base import MarketplaceClient
from src.apps.integrations.models import StoreConnection


class MarketplaceClientCreator(ABC):
    """Factory Method Creator interface for marketplace clients."""

    @abstractmethod
    def factory_method(self, connection: StoreConnection) -> MarketplaceClient:
        """Create concrete marketplace client for a platform."""

