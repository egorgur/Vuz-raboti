import time
import logging
from typing import Callable, Any
from datetime import datetime
from src.apps.integrations.clients.base import MarketplaceClient
from src.apps.integrations.models import StoreConnection
from src.apps.integrations.models import MarketplacePlatform

logger = logging.getLogger(__name__)


class MarketplaceClientDecorator(MarketplaceClient):
    """Базовый декоратор"""

    def __init__(self, client: MarketplaceClient):
        self._client = client

    @property
    def platform(self):
        return self._client.platform

    def __getattr__(self, name: str):
        return getattr(self._client, name)


def apply_decorators(client: MarketplaceClient, connection: StoreConnection) -> MarketplaceClient:
    """
    Применяет все необходимые декораторы по порядку.
    Порядок важен: сначала логи/метрики, потом ретраи.
    """
    # Можно легко добавлять/убирать декораторы
    client = LoggingDecorator(client)  # или MetricsDecorator
    client = RateLimitDecorator(client, platform=connection.platform)
    client = RetryDecorator(client, max_retries=3)

    return client


# src/apps/marketplaces/clients/decorators.py


logger = logging.getLogger(__name__)


class MarketplaceClientDecorator(MarketplaceClient):
    """Базовый класс-декоратор. Все остальные наследуются от него."""

    def __init__(self, client: MarketplaceClient):
        self._client = client

    @property
    def platform(self) -> MarketplacePlatform:
        return self._client.platform

    def __getattr__(self, name: str):
        """Прокидываем все не переопределённые методы на внутренний клиент"""
        return getattr(self._client, name)


# ====================== Конкретные декораторы ======================


class RetryDecorator(MarketplaceClientDecorator):
    """Ретраи с экспоненциальным backoff"""

    def __init__(self, client: MarketplaceClient, max_retries: int = 3, backoff: float = 1.5):
        super().__init__(client)
        self.max_retries = max_retries
        self.backoff = backoff

    def _retry(self, method_name: str, func: Callable, *args, **kwargs) -> Any:
        last_exception = None
        for attempt in range(self.max_retries):
            try:
                start = time.time()
                result = func(*args, **kwargs)
                duration = time.time() - start

                logger.info(
                    f"{self.platform.value.upper()} | {method_name} | SUCCESS | "
                    f"attempt={attempt+1}/{self.max_retries} | time={duration:.3f}s"
                )
                return result

            except Exception as e:
                last_exception = e
                logger.warning(
                    f"{self.platform.value.upper()} | {method_name} | FAILED | "
                    f"attempt={attempt+1}/{self.max_retries} | error={type(e).__name__}: {e}"
                )

                if attempt < self.max_retries - 1:
                    sleep_time = self.backoff**attempt
                    time.sleep(sleep_time)
                else:
                    logger.error(f"{self.platform.value.upper()} | {method_name} | ALL RETRIES FAILED", exc_info=True)
                    raise

        raise last_exception  # type: ignore[return-value]

    # Переопределяем ключевые методы
    def get_orders(self, since=None, status=None):
        return self._retry("get_orders", self._client.get_orders, since, status)

    def update_stock(self, sku: str, quantity: int, warehouse_id: str | None = None):
        return self._retry("update_stock", self._client.update_stock, sku, quantity, warehouse_id)

    def check_connection(self):
        return self._retry("check_connection", self._client.check_connection)


class LoggingDecorator(MarketplaceClientDecorator):
    """Простое логирование всех вызовов"""

    def _log_call(self, method_name: str, *args, **kwargs):
        logger.debug(f"{self.platform.value.upper()} | {method_name} called | " f"args={args} | kwargs={kwargs}")

    def get_orders(self, since=None, status=None):
        self._log_call("get_orders", since=since, status=status)
        return self._client.get_orders(since, status)

    def update_stock(self, sku: str, quantity: int, warehouse_id: str | None = None):
        self._log_call("update_stock", sku=sku, quantity=quantity, warehouse_id=warehouse_id)
        return self._client.update_stock(sku, quantity, warehouse_id)

    # Можно добавить для остальных методов или использовать __getattr__ + обёртку


class RateLimitDecorator(MarketplaceClientDecorator):
    """Простой rate-limit по платформе (можно улучшить с помощью ratelimit или token bucket)"""

    def __init__(self, client: MarketplaceClient, platform: MarketplacePlatform, calls_per_second: float = 2.0):
        super().__init__(client)
        self._platform = platform
        self.calls_per_second = calls_per_second
        self.last_call = 0.0

    @property
    def platform(self) -> MarketplacePlatform:
        return self._platform

    def _wait_if_needed(self):
        now = time.time()
        min_interval = 1.0 / self.calls_per_second
        if now - self.last_call < min_interval:
            time.sleep(min_interval - (now - self.last_call))
        self.last_call = time.time()

    def get_orders(self, since=None, status=None):
        self._wait_if_needed()
        return self._client.get_orders(since, status)

    def update_stock(self, sku: str, quantity: int, warehouse_id: str | None = None):
        self._wait_if_needed()
        return self._client.update_stock(sku, quantity, warehouse_id)


class RetryDecorator(MarketplaceClientDecorator):
    """Декоратор с ретраями и базовым логированием"""

    def __init__(self, client: MarketplaceClient, max_retries: int = 3, backoff: float = 1.5):
        super().__init__(client)
        self.max_retries = max_retries
        self.backoff = backoff

    def _retry(self, method_name: str, func: Callable, *args, **kwargs) -> Any:
        last_exception = None
        for attempt in range(self.max_retries):
            try:
                start = time.time()
                result = func(*args, **kwargs)
                duration = time.time() - start

                logger.info(
                    f"{self.platform.value} | {method_name} | success | attempt={attempt+1} | time={duration:.3f}s"
                )
                return result

            except Exception as e:
                last_exception = e
                logger.warning(
                    f"{self.platform.value} | {method_name} | failed | attempt={attempt+1}/{self.max_retries} | error={e}"
                )

                if attempt < self.max_retries - 1:
                    sleep_time = self.backoff**attempt
                    time.sleep(sleep_time)
                else:
                    logger.error(f"{self.platform.value} | {method_name} | all retries failed", exc_info=True)
                    raise

        raise last_exception  # type: ignore

    def get_orders(self, since: datetime | None = None, status: str | None = None) -> list[Order]:
        return self._retry("get_orders", self._client.get_orders, since, status)

    def update_stock(self, sku: str, quantity: int, warehouse_id: str | None = None) -> bool:
        return self._retry("update_stock", self._client.update_stock, sku, quantity, warehouse_id)

    # Добавляй остальные методы по аналогии (get_stock, update_product_card и т.д.)
    def check_connection(self) -> bool:
        return self._retry("check_connection", self._client.check_connection)
