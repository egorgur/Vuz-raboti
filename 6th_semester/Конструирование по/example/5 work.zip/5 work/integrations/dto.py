from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

from src.apps.marketplaces.models import MarketplacePlatform


@dataclass
class OrderItem:
    sku: str
    quantity: int
    price: int          # в копейках
    name: str


@dataclass
class Order:
    order_id: str                    # наш внутренний ID
    platform_order_id: str           # ID на Ozon
    platform: MarketplacePlatform
    status: str
    items: List[OrderItem]
    created_at: datetime
    customer_name: Optional[str] = None


@dataclass
class StockItem:
    sku: str
    quantity: int
    warehouse_id: Optional[str] = None


@dataclass
class Product:
    """Товар"""
    # Основные поля
    name: str
    offer_id: str
    price: str
    barcode: str
    
    # Опциональные поля
    description_category_id: Optional[int] = None
    new_description_category_id: int = 0
    color_image: str = ""
    currency_code: str = "RUB"
    depth: int = 0
    dimension_unit: str = "mm"
    height: int = 0
    width: int = 0
    weight: int = 0
    weight_unit: str = "g"
    old_price: str = ""
    primary_image: str = ""
    type_id: Optional[int] = None
    vat: str = "0"
    
    # Коллекции
    attributes: List[Attribute] = field(default_factory=list)
    complex_attributes: List[Any] = field(default_factory=list)
    images: List[str] = field(default_factory=list)
    images360: List[str] = field(default_factory=list)
    pdf_list: List[str] = field(default_factory=list)
    promotions: List[Promotion] = field(default_factory=list)