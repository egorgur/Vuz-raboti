from django.db import models
from django.utils.translation import gettext_lazy as _

from src.apps.organizations.models import Office


# ===================================================================
# 1. Платформы как отдельный Enum (лучше, чем TextChoices)
# ===================================================================
class MarketplacePlatform(models.TextChoices):
    AVITO = "avito", "Avito"
    OZON = "ozon", "Ozon"
    WILDBERRIES = "wildberries", "Wildberries"
    # YANDEX_MARKET = "yandex_market", "Яндекс Маркет"  # легко добавить


class ConnectionStatus(models.TextChoices):
    ACTIVE = "active", "Active"
    TOKEN_ERROR = "token_error", "Token error"
    DISCONNECTED = "disconnected", "Disconnected"

# ===================================================================
# 2. Основная модель подключения — стала проще и чище
# ===================================================================
class StoreConnection(models.Model):
    """
    Подключение кабинета маркетплейса к офису.
    Хранит только общие данные + зашифрованный payload.
    Вся специфика вынесена в стратегии/адаптеры.
    """

    office = models.ForeignKey(
        Office,
        on_delete=models.CASCADE,
        related_name="store_connections",
    )

    platform = models.CharField(
        max_length=32,
        choices=MarketplacePlatform.choices,
        verbose_name="Маркетплейс"
    )

    # Зашифрованные учётные данные (токены, client_id, secret и т.д.)
    encrypted_credentials = models.BinaryField(
        null=True,
        blank=True,
        verbose_name="Зашифрованные credentials"
    )

    status = models.CharField(
        max_length=32,
        choices=ConnectionStatus.choices,
        default=ConnectionStatus.DISCONNECTED,
        verbose_name="Статус подключения"
    )

    # Дополнительные метаданные (опционально)
    external_id = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        help_text="ID кабинета на стороне маркетплейса (если есть)"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "mp_integrations_store_connection"
        constraints = [
            models.UniqueConstraint(
                fields=["office", "platform"],
                name="uniq_office_marketplace_platform",
            ),
        ]
        verbose_name = "Подключение к маркетплейсу"
        verbose_name_plural = "Подключения к маркетплейсам"

    def __str__(self):
        return f"{self.office} — {self.get_platform_display()}"