import pandas as pd
import logging
from datetime import datetime
from pathlib import Path

from src.apps.marketplaces.models import StoreConnection
from src.apps.marketplaces.clients.base import MarketplaceClient
from src.apps.marketplaces.sync.pipeline import ProductSyncPipeline
from src.apps.marketplaces.dto import InternalStock, ProductDataChangedEvent

logger = logging.getLogger(__name__)


class ConcreteSyncroClassForStocks(ProductSyncPipeline):
    def __init__(self, connection: StoreConnection, client: MarketplaceClient):
        """
        Зависимости инжектируются через конструктор.
        """
        self.connection = connection
        self.client = client                     # <-- Dependency Injection

    # ====================== ОБЯЗАТЕЛЬНЫЕ МЕТОДЫ ======================

    def fetch_data(self, event: ProductDataChangedEvent):
        """Получение остатков через адаптер"""
        # Получаем данные через единый интерфейс клиента
        stock_items = self.client.get_stock(sku=getattr(event, 'sku', None))

        # Преобразуем в список словарей для удобства (pandas любит такой формат)
        return [
            {
                "sku": item.sku,
                "quantity": item.quantity,
                "warehouse_id": item.warehouse_id,
                "platform": self.connection.platform.value,
                "fetched_at": datetime.now().isoformat(),
                "internal_product_id": event.internal_product_id
            }
            for item in stock_items
        ]

    def map_to_internal(self, raw_data: list[dict], event: ProductDataChangedEvent) -> InternalStock | None:
        """Маппинг в внутреннюю модель"""
        if not raw_data:
            return None

        # Берём первое значение (или адаптируй под множественные остатки)
        data = raw_data[0]

        return InternalStock(
            internal_product_id=event.internal_product_id,
            sku=data["sku"],
            quantity=data["quantity"],
            warehouse_id=data.get("warehouse_id"),
            source_platform=self.connection.platform,
            updated_at=datetime.now()
        )

    # ====================== ХУКИ ======================

    def after_sync(self, event: ProductDataChangedEvent):
        """
        Хук: здесь сохраняем snapshot остатков в CSV.
        Это единственное место, где мы добавляем сохранение в файл.
        """
        logger.info(f"Синхронизация остатков для {self.connection.platform} завершена")

        # Получаем сырые данные заново? Нет — лучше сохранить их во время fetch.
        # Решение: сохраняем внутри after_sync, но данные нужно где-то взять.
        
        raw_data = self.fetch_data(event)

        if not raw_data:
            logger.warning("Нет данных для сохранения в CSV")
            return

        # Создаём DataFrame и сохраняем
        df = pd.DataFrame(raw_data)

        # Генерируем имя файла
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"stocks_{self.connection.platform.value}_{timestamp}.csv"
        
        # Путь к файлу (рекомендуется создать папку заранее)
        filepath = Path(f"data/snapshots/stocks/{filename}")
        filepath.parent.mkdir(parents=True, exist_ok=True)

        df.to_csv(filepath, index=False, encoding='utf-8')

        logger.info(f"Снимок остатков сохранён в CSV: {filepath}")

    def before_propagate(self, data: InternalStock | None):
        """Хук: можно добавить логику пропуска распространения"""
        if data is None or data.quantity < 0:
            logger.warning("Распространение остатков пропущено: некорректные данные")
            # Можно вернуть False, если базовый класс это поддерживает
            pass

class ConcreteSyncroClassForProductCard(ProductSyncPipeline):
    """
    Конкретная реализация синхронизации полной карточки товара (Product Card).
    Только переопределяем существующие методы.
    """

    def __init__(self, connection: StoreConnection):
        self.connection = connection
        self.client = MarketplaceClientFactory.get_client(connection)

    # ====================== ОБЯЗАТЕЛЬНЫЕ МЕТОДЫ ======================

    def fetch_data(self, event: ProductDataChangedEvent):
        """Получение карточки товара через адаптер"""
        sku = getattr(event, 'sku', None)
        if not sku:
            logger.warning("SKU не передан в событии для получения карточки товара")
            return []

        product_card = self.client.get_product_card(sku)

        if not product_card:
            return []

        # Возвращаем список с одним словарём для единообразия с pandas
        return [{
            "sku": product_card.sku,
            "name": product_card.name,
            "price": product_card.price,
            "description": product_card.description or "",
            "platform": self.connection.platform.value,
            "fetched_at": datetime.now().isoformat(),
            "internal_product_id": event.internal_product_id
        }]

    def map_to_internal(self, raw_data: list[dict], event: ProductDataChangedEvent) -> ProductCard | None:
        """Маппинг в внутреннюю модель ProductCard"""
        if not raw_data:
            return None

        data = raw_data[0]

        return ProductCard(
            sku=data["sku"],
            name=data["name"],
            price=data["price"],
            description=data.get("description"),
            # Добавляй другие поля при необходимости
        )

    # ====================== ХУКИ ======================


    def before_propagate(self, data: ProductCard | None):
        """Хук перед распространением изменений"""
        if data is None:
            logger.warning("Распространение карточки товара пропущено: данных нет")
            # Здесь можно добавить логику пропуска
            pass