from abc import ABC, abstractmethod


class ProductSyncPipeline(ABC):
    @abstractmethod
    def synchronize(self, event: ProductDataChangedEvent):
        self.before_sync(event)  # хук

        internal_data = self.fetch_data(event)  # обязательно переопределять

        self.save_to_db(internal_data)  # общий

        self.before_propagate(internal_data)  # хук
        self.propagate_to_other_platforms(internal_data)  # абстрактный
        self.after_propagate(internal_data)  # хук

        self.after_sync(event)  # хук

    # ====================== ХУКИ ======================
    @abstractmethod
    def before_sync(self, event):
        pass

    @abstractmethod
    def after_sync(self, event):
        pass

    @abstractmethod
    def before_propagate(self, data):
        """Можно переопределить, чтобы пропустить распространение для определённых случаев"""
        pass

    # ====================== ОБЯЗАТЕЛЬНЫЕ МЕТОДЫ ======================
    @abstractmethod
    def fetch_data(self, event):
        raise NotImplementedError("Подкласс должен реализовать получение данных")
