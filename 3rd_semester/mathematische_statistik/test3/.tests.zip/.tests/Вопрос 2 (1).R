data <- c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 
          1, 1, 1, 1, 
          1, 1, 
          1, 1, 
          1, 1, 2, 2, 3, 5) #МЕТОД ПОДБОРА, САМОПРОВЕРКА!!!
print(data) # Вывод выборки


#=====================================================================================





# Создание эмпирической функции распределения
empirical_function <- ecdf(data)

# Построение графика
plot(empirical_function, 
     main = "Эмпирическая функция распределения", 
     xlab = "x", 
     ylab = "F(x)", 
     col = "blue", 
     lwd = 2)
grid()

# Добавление подписей к точкам
points(sort(data), empirical_function(sort(data)), col = "red", pch = 16)
text(sort(data), empirical_function(sort(data)), 
     labels = round(empirical_function(sort(data)), 3), 
     pos = 3, col = "red")

